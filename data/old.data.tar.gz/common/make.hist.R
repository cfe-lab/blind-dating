#!/usr/bin/RScript

make.hist <- function(pdf.file, good.fits, data.csv, sim.csv, sim.lat.csv) {
	pdf(pdf.file, width=7, height=7)
	par(mfrow=c(1, 1), pty="s")
	dev.hist = dev.cur()

	data.good <- read.csv(good.fits, header=F)
	data.df <- read.csv(data.csv, header=T)
	
	data.df$Normal.Error <- -data.df$Normal.Error
	
	data.good.df <- data.df[data.df$Patient %in% data.good[,1],]

	simulated.df <- read.csv(sim.csv, header=T)
	latent.df <- read.csv(sim.lat.csv, header=T)

	data.split <- split(data.good.df, data.good.df$Patient)

	ds <- lapply(data.split, function(x) density(x$Normal.Error, bw=0.15))
	
	par(mar=c(5, 5, 2, 2), ps=30)
	plot(c(-001,-100), xlim=c(-2.7, 2.7), ylim=c(0, 3), xlab="Normalized Difference", ylab="Density", axes=F, cex.lab=1)
	#c(min(data.good.df$Normal.Error), max(data.good.df$Normal.Error))
	axis(side=1, at=seq(-2.5, 2.5, by=1), tck=.01, cex.axis=.8)
	#seq(floor(min(data.good.df$Normal.Error)), ceiling(max(data.good.df$Normal.Error))
	axis(side=2, at=seq(0, 3, by=0.5), tck=.01, cex.axis=.8)
	box()
	
	suppress <- lapply(ds, polygon, col=rgb(0.5, 0.0, 0.9, 1/length(data.good[,1])), xlim=c(-0.1,0.2), border=rgb(1,1,1,0))
	
	lines(density(-simulated.df$Normal.Error, bw=.15), lwd=2, col="#0000ffa0")
	lines(density(-latent.df$Normal.Error, bw=.15), lwd=2, col="#00ff00a0")
	
	abline(v=median(-simulated.df$Normal.Error), col="#0000ffa0", lwd=1)
	abline(v=median(-latent.df$Normal.Error), col="#00ff00a0", lwd=1)
	abline(v=median(data.good.df$Normal.Error), col=rgb(.5, 0, .9, .7), lwd=1)
	
	legend(0.4, 3.08, c("Real data", "Simulated data", "(no latency)", "Simulated data", "(latency)"), col=c(rgb(.5, 0, .9, .7), "#0000ffa0", NA, "#00ff00a0", NA), pch=c(15, NA, NA, NA, NA), lty=c(NA, 1, NA, 1, NA), lwd=c(NA, 3, NA, 3, NA), cex=.7, y.intersp=1.5, pt.cex=3)
	#min(data.good.df$Normal.Error) + (max(data.good.df$Normal.Error) - min(data.good.df$Normal.Error)) * .005
	
	dev.off()
}

make.hist("ancre/ancre.hist.pdf", "ancre/good_fits.txt", "ancre/data.rttall.csv", "simulated/data.csv", "latent_sim/run1/data.csv")
make.hist("lanl/lanl.hist.pdf", "lanl/good_fits.txt", "lanl/data.rttall.csv", "simulated/data.csv", "latent_sim/run1/data.csv")
#make.hist("ancre/ancre.hist1.pdf", "ancre/good_fits.txt", "ancre/data.rttall.csv", "latent_sim/run1/data.csv")
#make.hist("ancre/ancre.hist2.pdf", "ancre/good_fits.txt", "ancre/data.rttall.csv", "latent_sim/run2/data.csv")
#make.hist("ancre/ancre.hist.sim.pdf", "ancre/good_fits.txt", "ancre/data.rttall.csv", "simulated/data.csv")
#make.hist("lanl/lanl.hist1.pdf", "lanl/good_fits.txt", "lanl/data.rttall.csv", "latent_sim/run1/data.csv")
#make.hist("lanl/lanl.hist2.pdf", "lanl/good_fits.txt", "lanl/data.rttall.csv", "latent_sim/run2/data.csv")
#make.hist("lanl/lanl.hist.sim.pdf", "lanl/good_fits.txt", "lanl/data.rttall.csv", "simulated/data.csv")