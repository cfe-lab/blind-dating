library(ggtree)
library(ape)
library(phylobase)

args.all <- commandArgs(trailingOnly = F)

if (any(grep("--file=", args.all))) {
	source.dir <- dirname(sub("--file=", "", args.all[grep("--file=", args.all)]))
} else {
	file.arg <- F

	for (i in 1:length(args.all)) {
		if (file.arg) {
			source.dir <- dirname(args.all[i])
		
			break
		}
		
		file.arg <- args.all[i] == '-f'
	}
}

args <- commandArgs(trailing = T)

TREE_FILE <- args[1]
DATES_FILE <- args[2]
STATS_FILE <- args[3]
PLOT_FILE <- args[4]
DATES_KNOWN <- as.numeric(args[5])
DATES_AS_DATES <- as.numeric(args[6])

my.ggplot <- function(tree, ...) {
	ggtree(tree, ladderize=F,...) + geom_tiplab(aes(label=id, colour=type), size=1.2) + scale_colour_manual(breaks=c("PLASMA", "PBMC"), limits=c("PLASMA", "PBMC"), values=c('blue', 'orange'), guide=NULL)
}

get.date <- function(date) {
	as.character(
		if (DATES_AS_DATES)
			as.Date(date, origin=as.Date("1970-01-01"))
		else
			date
	)
}

tree <- ladderize(read.tree(TREE_FILE))

n <- length(tree$tip.label)
tree$node.label <- paste0("N", 1:tree$Nnode)

data <- data.frame(node=1:(n + tree$Nnode), id=c(gsub("^(.+?_.+?)_.+$", "\\1", tree$tip.label), tree$node.label), type=c(gsub("^.+_(.+)_.+$", "\\1", tree$tip.label), rep("NODE", tree$Nnode)), date=c(as.numeric(gsub("^.+_(.+)$", "\\1", tree$tip.label)), rep(NA, tree$Nnode)), dist=node.depth.edgelength(tree), stringsAsFactors=F)

l <- glm(date ~ dist, data=data, subset=type=="PLASMA")
l.null <- glm(date ~ 1, data=data, subset=type=="PLASMA")

stats <- data.frame(mutation.rate=1/coef(l)[[2]],root.date=-coef(l)[[1]]/coef(l)[[2]],AIC=l$aic, null.AIC=l.null$aic, p.value=1-pchisq(l.null$aic - l$aic + 2, df=1))

write.table(stats, row.names=F, col.names=c("Estimated Mutation Rate", "Estimated Root Date", "AIC", "Null AIC", "p-value"), file=STATS_FILE, sep=",")

data <- cbind(data, date.lm=coef(l)[[1]] + coef(l)[[2]] * data$dist, date.diff=coef(l)[[1]] + coef(l)[[2]] * data$dist - data$date, date.ml=estimate.dates(tree, data$date, 1/coef(l)[[2]], lik.tol=1e-5, nsteps=0, show.steps=1000))

write.table(cbind(data.ogr$id, get.date(data.ogr$date), get.date(data.ogr$date.lm), data.ogr$date.diff)[data.ogr$type=="PBMC", ], row.names=F, col.names=c("ID", "Sample Date", "Estimated Integration Date", "Date Difference (days)"), file=DATES_FILE, sep=",")

ptree <- phylo4d(tree, all.data=data)

pdf(PLOT_FILE, height=3.75, width=4.5)
my.ggplot(ptree) + scale_y_reverse() + scale_x_continuous(limits=c(0, .2))
my.ggplot(ptree, yscale="date.ml") + coord_flip() + geom_tippoint(aes(colour=type, shape=type), size=1.1) + scale_y_continuous(breaks=c(9131, 10957, 12784, 14610, 16436), labels=c("1995", "2000", "2005", "2010", "2015"), limits=c(8766, 17532)) + theme(axis.text.x=element_text(colour='black', size=10), axis.line.x=element_line(colour='black', size=1), axis.ticks.x=element_line(colour='black', size=1), axis.ticks.length=unit(5, 'pt')) + geom_abline(intercept=coef(l)[[1]], slope=coef(l)[[2]], colour="#ff0000a0", linetype=2, size=1)
dev.off()