library(ape)
library(ggtree)
library(phylobase)

tree <- reorder(read.tree("patient_1943.tre")) 

n <- length(tree$tip.label)
tree$node.label <- as.character(1:tree$Nnode)

type <- c(gsub(".+_(PLASMA|PBMC)_.+", "\\1", tree$tip.label), rep("internal", tree$Nnode))
date <- c(as.numeric(gsub(".+_(.+)", "\\1", tree$tip.label)), rep(NA, tree$Nnode))
dist <- node.depth.edgelength(tree)

df <- data.frame(type=type, date=date, dist=dist, stringsAsFactors=F)

g <- glm(dist ~ date, data=df, subset=type=="PLASMA")

a <- coef(g)[[1]]
mu <- coef(g)[[2]]

trimmed.tree <- drop.tip(tree, which(type=="PBMC"))

trimmed.date <- estimate.dates(trimmed.tree, date[type=="PLASMA"], mu, nstep=0, show.steps=100, lik.tol=1e-6)

est.dates <- rep(NA, n + tree$Nnode)
est.dates[c(match(trimmed.tree$tip.label, tree$tip.label), match(trimmed.tree$node.label, tree$node.label) + n)] <- trimmed.date

for (i in 1:20) {
	est.dates <- unlist(lapply(1:(tree$Nnode + n), function(x) {
		if (is.na(est.dates[x])) {
			e <- which(tree$edge[, 2] == x)
			if (is.na(est.dates[tree$edge[e, 1]]))
				NA
			else
				est.dates[tree$edge[e, 1]] + tree$edge.length[e] / mu
		} else
			est.dates[x]
	}))
}

df <-  data.frame(type=type, date=date, dist=dist, rep=dist/mu - a/mu, est.date=est.dates, stringsAsFactors=F)
ptree <- phylo4d(tree, all.data=df)

ggtree(ptree, colour="gray", size=1, yscale="est.date") + geom_abline(slope=1/coef(g)[[2]], intercept=-coef(g)[[1]]/coef(g)[[2]], linetype=2, size=1.5) + geom_tippoint(aes(shape=type, color=type), size=8) + coord_flip() + theme(legend.position='right') + theme_bw() + theme(panel.grid = element_blank()) + scale_y_continuous(name="Date sampled (year)", breaks=as.numeric(as.Date(paste0(seps, "-01-01"))) + 42583 - 17014, labels=as.character(seps)) + scale_x_continuous("Divergence from root", breaks=seq(0, 0.2, by=0.04)) + scale_shape_manual(name="Type", breaks=c("PLASMA", "PBMC"), labels=c("Plasma samples", "PBMC samples"), values=c(18, 16)) + scale_colour_manual(name="Type", breaks=c("PLASMA", "PBMC"), labels=c("Plasma samples", "PBMC samples"), values=c("#f06020", "#0040f080")) + theme(text=element_text(size=40, color="black"), axis.ticks.length=unit(.5, 'cm'), line=element_line(size=2), legend.key.size=unit(1.2, 'cm'), legend.background=element_rect(color="#000000"), panel.border=element_rect(size=2))
















f <- read.fasta(paste0("rep_1/16_contingency/", gen, ".fasta"))
f <- f[grep("Node", names(f), invert=T)]
cat(paste0("\n", gen, "\n"), file="resistant.txt", append=T)

m <- substr(n, 1, 1)
cod <- as.numeric(gsub(".([0123456789]+)", "\\1", n))
muts <-unlist(lapply(f, function(x) toupper(x[[cod]])))
found <- sort(muts[muts != m & muts %in% MUTATIONS[[gen]][[n]]])
cat(n, paste(names(found), found, sep="_"), sep="\n", file="resistant.txt", append=T)


s <- lapply(names(MUTATIONS), function(gen) {

 f <- read.fasta(paste0("rep_1/16_contingency/", gen, ".fasta"))
 cat(paste0("\n", gen, "\n"))
 s <- lapply(names(MUTATIONS[[gen]]), function(n)  {
 m <- substr(n, 1, 1)
 cod <- as.numeric(gsub(".([0123456789]+)", "\\1", n))
 muts <-unlist(lapply(f, function(x) toupper(x[[cod]])))
 found <- muts[muts != m & muts %in% MUTATIONS[[gen]][[n]]]
 cat("\n", n, "\n")
 unique(found)
  })
 s
 })






