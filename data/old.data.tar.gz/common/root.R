library(ape)
library(parallel)

options('mc.cores'=10)

args.all <- commandArgs(trailingOnly = F)

if (any(grep("--file=", args.all))) {
	source.dir <- dirname(sub("--file=", "", args.all[grep("--file=", args.all)]))
} else {
	file.arg <- F

	for (i in 1:length(args.all)) {
		if (file.arg) {
			source.dir <- dirname(args.all[i])
		
			break
		}
		
		file.arg <- args.all[i] == '-f'
	}
}

source(file.path(source.dir, 'rtt.R'), chdir=T)
source(file.path(source.dir, 'test.R'), chdir=T)

args <- commandArgs(trailingOnly = T)

suffix = args[1]
use.rtt <- as.integer(args[2])		# 0 = no, 1 = yes (only plasma), 2 = yes (all)

trees.read <- function(base.path) {
	trs <- dir(base.path)[grep('.tre', dir(base.path))]
	
	print(trs)
	
	ml.tree.read <- function(tr) {	
		tree = read.tree(paste(base.path, tr, sep='/'))
			
		if (sum("REFERENCE"==tree$tip.label) > 0) {
			if (use.rtt)			
				drop.tip(tree, "REFERENCE")
			else
				drop.tip(root(tree, "REFERENCE"), "REFERENCE")
		}
		else
			tree
			
	}
	
	trees <- lapply(trs, ml.tree.read)
	names(trees) <- trs	
	trees
}

trees <- trees.read("trees")

trees.root <- if (use.rtt) {
	mclapply(trees, function(tree) {	
		plasma.dates <- as.numeric(gsub("^.+_(.+)$", "\\1", tree$tip.label))
		tip.pbmc <- as.numeric(gsub("^.+_(.+)_.+$", "\\1", tree$tip.label)) == "PBMC"
	
		if (use.rtt == 1)
			plasma.dates[tip.pbmc] <- NA
			
		rtt(tree, plasma.dates, objective='rms', opt.tol=1e-8)
	})
} else
	trees

suppress <- lapply(names(trees.root), function(tr) write.tree(trees.root[[tr]], paste0("trees.rooted/", gsub("^(.+).tre", "\\1", tr), suffix, ".tre")))