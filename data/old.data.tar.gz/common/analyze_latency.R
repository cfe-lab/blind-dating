#!/usr/bin/Rscript

df <- read.csv("data.csv", header=T)
latency <- read.csv("latency.csv", header=T)

latency <- latency[latency$latency != "latency", ]

f <- as.factor(c(rep(1, 50), unlist(lapply(10:19, rep, 50)), rep(2, 50), unlist(lapply(20:29, rep, 50)), rep(3, 50), unlist(lapply(30:39, rep, 50)), rep(4, 50), unlist(lapply(40:49, rep, 50)), rep(5, 50), rep(50, 50), unlist(lapply(6:9, rep, 50))))

latency <- split(latency, as.factor(df$Patient))
df <- split(df, f)

diffs <- unlist(lapply(1:50, function(x) df[[x]][order(df[[x]]$Seq.ID), "Error"] - as.numeric(as.character(latency[[x]][order(latency[[x]]$id), "latency"]))))

cat(paste0("RMSE: ", sqrt(sum(diffs^2)/length(diffs)), "\n"))
cat(paste0("median: ", median(diffs), "\n"))
cat(paste0("mean: ", mean(diffs), "\n"))