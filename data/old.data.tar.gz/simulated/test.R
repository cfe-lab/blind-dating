#!/usr/bin/Rscript

library(mgcv)

df <- read.csv("data.csv", header=T)

pdf("gam.pdf")

n <- length(unique(df$Patient))
colors <- unlist(lapply(seq(1, n), function(x) {
	if (x < n / 3) {
		return(rgb(1 - x * 3 / n, x * 3 / n, 0, .1))
	} else if (x < 2 * n / 3) {
		return(rgb(0, 2 - x * 3 / n, x * 3 / n - 1, .1))
	} else {
		return(rgb(x * 3 / n - 2, 0, 3 - x * 3 / n, .1))
	}
}))

with(df, plot(Distance, Error, pch=20, col=colors[Patient]))
lines(c(-1, 1), c(0, 0), col=rgb(0, 0, 0, .5))

for (i in 1:50) {
	model <- gam(Error ~ s(Distance), data=df, subset=(Patient==i))
	x <- seq(min(df[df$Patient==i,"Distance"]), max(df[df$Patient==i,"Distance"]), length.out=1000)
	y <- predict(model, newdata=data.frame(Distance=x))
	for (j in 1:5)
		lines(x, y, col=colors[i])
}

dev.off()